/**
* @author amanu1
* 
 * Utility class to read values from ACS AEM Commons multifieldpanel. If the authored node is not available for the current resource, it looks up
* in the content hierarchy.
*/

package org.myapp.myappe.core.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.script.Bindings;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.scripting.sightly.pojo.Use;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.acs.commons.widgets.MultiFieldPanelFunctions;
import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;

public class ACSMultiFieldReader implements Use {

    private String name;
    private Resource resource;
    private static final Logger log = LoggerFactory.getLogger(ACSMultiFieldReader.class);
   
    @Override
    public void init(Bindings bindings) {
             name = (String) bindings.get("name");
        resource = (Resource) bindings.get("resource");
    }

    /**
     * @return
     */
    public List<Map<String, String>> getValues() {          
       List<Map<String, String>> values = new ArrayList<Map<String, String>>();
       if(resource != null){
              values = MultiFieldPanelFunctions.getMultiFieldPanelValues(resource, name);
              if (values != null && values.size() > 0){
                    return values;
              }else{
                    InheritanceValueMap inheritanceValueMap = new HierarchyNodeInheritanceValueMap(resource);
                    values = getInheritedValues(inheritanceValueMap, name);
                    return values;
              }
       }
       return values;
     }
     
    /**
     * @param inheritanceValueMap
     * @param name
     * @return
     */
    private List<Map<String, String>> getInheritedValues(InheritanceValueMap inheritanceValueMap, String name) {
       List<Map<String, String>> results = new ArrayList<Map<String, String>>();           
        if (inheritanceValueMap != null) { 
            String[] values = inheritanceValueMap.getInherited(name, String[].class);
            if(values !=null){
                   for (String value : values) { 
                        try { 
                           JSONObject parsedJson = new JSONObject(value); 
                           Map<String, String> columnMap = new HashMap<String, String>(); 
                           for (Iterator<String> iterator = parsedJson.keys(); iterator.hasNext();) { 
                               String key = iterator.next(); 
                               String innerValue = parsedJson.getString(key); 
                               columnMap.put(key, innerValue); 
                           } 
                           results.add(columnMap); 
                        } catch (JSONException e) { 
                           log.error(String.format("Unable to parse JSON in %s property of %s", name, resource.getPath()), e); 
                        } 
                    }
            }
        } 
        return results;          
    }
}
