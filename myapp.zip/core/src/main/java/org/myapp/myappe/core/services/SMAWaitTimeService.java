package org.myapp.myappe.core.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.auth.oauth2.ClientCredentialsTokenRequest;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpMethods;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestFactory;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpResponse;
import com.google.api.client.http.javanet.NetHttpTransport;

/**
 * @author amanu1
 *
 */
@Component(metatype=true, immediate=true, label="SMA Wait time Service", description="Southwest Medical Associates Wait time Service")
@Service(value=SMAWaitTimeService.class)
@Properties({ @Property(
		label = "Token Location",
		name = "sma.api.tokenlocation",
		description = "SMA API Token Location",
		value = "/api/oauth2/token") ,
		@Property(
	    label = "Client Id",
		name = "sma.api.clientid",
		description = "SMA API Client Id",
		value = "optumportal"),
		@Property(
	    label = "Client Secret",
		name = "sma.api.clientsecret",
		description = "SMA API Client Secret",
		value = "h]Jk2YXQek"),
		@Property(
		label = "Scope",
		name = "sma.api.scope",
		description = "SMA API Scope",
		value = "optumsvc"),
		@Property(
	    label = "Urgent Care Wait time endpoint",
		name = "sma.api.ucwt.endpoint",
		description = "SMA Urgent Care Wait time endpoint",
		value = "/api/public/v1/UrgentCares"),
		@Property(
		label = "Convenient Care Wait time endpoint",
		name = "sma.api.ccwt.endpoint",
		description = "SMA Convenient Care Wait time endpoint",
		value = ""),
		@Property(
		label = "API Root Path",
		name = "sma.environment.rootpath",
		description = "SMA API Environment Root Path",
		value = "https://apitest.sierrahealth.com")
})

public class SMAWaitTimeService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SMAWaitTimeService.class);
	
	private static String tokenLocation = "";
	private static String clientId = "";
	private static String clientSecret = "";
	private static String scope = "";
	private static String ucendpoint = "";
	private static String ccendpoint = "";
	private static String rootpath = "";
	
	
	/**
	 * @param context
	 * @throws Exception
	 */
	protected void activate(final ComponentContext context) throws Exception {
		@SuppressWarnings("unchecked")
		Dictionary<String,String> props = context.getProperties();
		if (props!=null) {
			tokenLocation = props.get("sma.api.tokenlocation");
			clientId = props.get("sma.api.clientid");
			clientSecret = props.get("sma.api.clientsecret");
			scope = props.get("sma.api.scope");
			ucendpoint = props.get("sma.api.ucwt.endpoint");
			ccendpoint = props.get("sma.api.ccwt.endpoint");
			rootpath = props.get("sma.environment.rootpath");
		}
	}
	
	/**
	 * @return
	 * @throws IOException 
	 */
	public String getUrgetCareWaitTime() {
		
		 String accessToken = null;
		  HttpResponse restresp = null;
			try {
		 NetHttpTransport netHttpTransport = new NetHttpTransport();
		 accessToken = getAccessToken();
		 GenericUrl Url = new GenericUrl(rootpath + ucendpoint);
         netHttpTransport.createRequestFactory(new HttpRequestInitializer() {
			
			@Override
			public void initialize(HttpRequest request) throws IOException {
				HttpHeaders headers = new HttpHeaders();
			    String accept = "Authorization" + "," + "Bearer "+ getAccessToken();
               headers.setCacheControl("no-cache");                         
               request.setHeaders(headers.setAccept(accept));
               request.setRequestMethod(HttpMethods.GET);

			}
		});
         			Credential credential =
        	        new Credential(BearerToken.authorizationHeaderAccessMethod()).setAccessToken(accessToken);
        	    HttpRequestFactory requestFactory = netHttpTransport.createRequestFactory(credential);
					restresp = requestFactory.buildGetRequest(Url).execute();
					  return  restresp.parseAsString();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					LOGGER.error("IOException in UrgentCareWaitTimeServlet.java");
					e.printStackTrace();
					return"{\"message\":\"" + e.getMessage() + "\"}";
				}
        	
      
	}
	
	/**
	 * @return
	 * @throws IOException 
	
	 */

	private String getAccessToken() throws IOException {
		
		TokenResponse response = null;            
              ArrayList<String> scopes = new ArrayList<String>();
              scopes.add(scope);
     
              
              NetHttpTransport netHttpTransport = new NetHttpTransport();
              netHttpTransport.createRequestFactory(new HttpRequestInitializer() {
				
				@Override
				public void initialize(HttpRequest request) {
					HttpHeaders headers = new HttpHeaders();
                    headers.setContentType("application/x-www-form-urlencoded");
                    headers.setCacheControl("no-cache");                         
                    request.setHeaders(headers);                                
                    request.setRequestMethod(HttpMethods.POST);
					
				}
			});
              
              ClientCredentialsTokenRequest ccRequest =
                      new ClientCredentialsTokenRequest(netHttpTransport, new com.google.api.client.json.jackson2.JacksonFactory(),
                          new GenericUrl(rootpath + tokenLocation))
                                 .setGrantType("client_credentials")
                                 .setScopes(scopes)
                                 .setClientAuthentication(new BasicAuthentication(clientId, clientSecret));
                
               response = ccRequest.execute();
		return response.getAccessToken();
	}
	

}
